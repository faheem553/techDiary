export class Task {
id:any;
task_name:string="";
date:any='';
createdBy: any = 0;
updatedDate:any='';
}
